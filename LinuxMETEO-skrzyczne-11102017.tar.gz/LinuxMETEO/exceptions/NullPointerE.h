/*
 * NullPointerE.h
 *
 *  Created on: 22.09.2017
 *      Author: mateusz
 */

#ifndef EXCEPTIONS_NULLPOINTERE_H_
#define EXCEPTIONS_NULLPOINTERE_H_

class NullPointerE {
public:
	NullPointerE();
	virtual ~NullPointerE();
};

#endif /* EXCEPTIONS_NULLPOINTERE_H_ */
