/*
 * ChannelValue.cpp
 *
 *  Created on: 16.09.2017
 *      Author: mateusz
 */

#include "ChannelValueFoundation.h"

ChannelValueFoundation::ChannelValueFoundation() {
	// TODO Auto-generated constructor stub

}

ChannelValueFoundation::~ChannelValueFoundation() {
	// TODO Auto-generated destructor stub
}

