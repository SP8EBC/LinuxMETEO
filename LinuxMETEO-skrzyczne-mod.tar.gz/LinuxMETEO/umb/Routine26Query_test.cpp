/*
 * Routine26Query_test.cpp
 *
 *  Created on: 23.09.2017
 *      Author: mateusz
 */

#include "Routine26Query.h"

