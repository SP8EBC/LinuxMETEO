/*
 * UsageParseError.h
 *
 *  Created on: 24.09.2017
 *      Author: mateusz
 */

#ifndef EXCEPTIONS_USAGEPARSEERROR_H_
#define EXCEPTIONS_USAGEPARSEERROR_H_

class UsageParseError {
public:
	UsageParseError();
	virtual ~UsageParseError();
};

#endif /* EXCEPTIONS_USAGEPARSEERROR_H_ */
