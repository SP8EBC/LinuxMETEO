/*
 * UsageParseError.cpp
 *
 *  Created on: 24.09.2017
 *      Author: mateusz
 */

#include "UsageParseError.h"

UsageParseError::UsageParseError() {
	// TODO Auto-generated constructor stub

}

UsageParseError::~UsageParseError() {
	// TODO Auto-generated destructor stub
}

