/*
 * OutputValues.cpp
 *
 *  Created on: 24.09.2017
 *      Author: mateusz
 */

#include "OutputValues.h"

OutputValues::OutputValues() {
	// TODO Auto-generated constructor stub

}

OutputValues::~OutputValues() {
	// TODO Auto-generated destructor stub
}

