/*
 * Float_test.cpp
 *
 *  Created on: 20.09.2017
 *      Author: mateusz
 */

#include "Float.h"

