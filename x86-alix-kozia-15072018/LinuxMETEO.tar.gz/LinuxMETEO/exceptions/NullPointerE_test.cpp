/*
 * NullPointerE_test.cpp
 *
 *  Created on: 22.09.2017
 *      Author: mateusz
 */

#include "NullPointerE.h"

