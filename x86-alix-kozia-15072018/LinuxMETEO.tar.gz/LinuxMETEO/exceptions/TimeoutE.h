/*
 * TimeoutE.h
 *
 *  Created on: 23.09.2017
 *      Author: mateusz
 */

#ifndef EXCEPTIONS_TIMEOUTE_H_
#define EXCEPTIONS_TIMEOUTE_H_

class TimeoutE {
public:
	TimeoutE();
	virtual ~TimeoutE();
};

#endif /* EXCEPTIONS_TIMEOUTE_H_ */
